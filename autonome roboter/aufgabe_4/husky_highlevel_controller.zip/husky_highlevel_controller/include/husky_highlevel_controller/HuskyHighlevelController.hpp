#pragma once

#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Twist.h>
#include <tf2_ros/transform_listener.h>
#include <tf2/utils.h>
#include <tf/tf.h>
#include <visualization_msgs/Marker.h>
#include "husky_highlevel_controller/Algorithm.hpp"
#include <string>

#include "husky_highlevel_controller/PillarPosition.h"

#include <actionlib/server/simple_action_server.h>
#include <husky_highlevel_controller/HuskyPillarAction.h>

namespace husky_highlevel_controller {

/*!
 * Class containing the Husky Highlevel Controller
 */
class HuskyHighlevelController {
public:
	/*!
	 * Constructor.
	 */
	HuskyHighlevelController(ros::NodeHandle& nodeHandle);

	/*!
	 * Destructor.
	 */
	virtual ~HuskyHighlevelController();

private:
	ros::NodeHandle nodeHandle_;
	ros::Subscriber subscriber_;
	ros::Publisher cmd_vel_publisher_;
	void pillarCallback(const husky_highlevel_controller::PillarPosition& msg);
	void loadParameters();
	void publishMarker(double x, double y, std::string originFrame, std::string targetFrame);
	void executePillarDrive(const husky_highlevel_controller::HuskyPillarGoalConstPtr& goal);

	Algorithm algorithm_;
	std::string pillar_topic_;
	int queue_size_;
	float kp_;
	tf2_ros::Buffer tfBuffer_;
	tf2_ros::TransformListener tfListener_;
	ros::Publisher vis_pub_;

	double minimalDistance;
	float pillarAngle;
	double angle_offset;
	std::string frame_id;
	double min_distance_;

	actionlib::SimpleActionServer<husky_highlevel_controller::HuskyPillarAction> actionServer_;
	husky_highlevel_controller::HuskyPillarFeedback feedback_;
	husky_highlevel_controller::HuskyPillarResult result_;
};

} /* namespace */
