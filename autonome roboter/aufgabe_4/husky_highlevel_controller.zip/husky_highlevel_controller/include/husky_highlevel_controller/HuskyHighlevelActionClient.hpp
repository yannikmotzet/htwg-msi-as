#pragma once

#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Twist.h>
#include <tf2_ros/transform_listener.h>
#include <tf2/utils.h>
#include <tf/tf.h>
#include <visualization_msgs/Marker.h>
#include "husky_highlevel_controller/Algorithm.hpp"
#include <string>

#include <actionlib/client/simple_action_client.h>
#include <husky_highlevel_controller/HuskyPillarAction.h>



namespace husky_highlevel_controller {

/*!
 * Class containing the Husky Highlevel Controller
 */
class HuskyHighlevelActionClient {
public:
	/*!
	 * Constructor.
	 */
	HuskyHighlevelActionClient(ros::NodeHandle& nodeHandle);

	/*!
	 * Destructor.
	 */
	virtual ~HuskyHighlevelActionClient();

private:
	ros::NodeHandle nodeHandle_;
	actionlib::SimpleActionClient<husky_highlevel_controller::HuskyPillarAction> actionClient_;
	husky_highlevel_controller::HuskyPillarGoal goal;
};

} /* namespace */
