#pragma once

#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Twist.h>
#include <tf2_ros/transform_listener.h>
#include <tf2/utils.h>
#include <tf/tf.h>
#include <visualization_msgs/Marker.h>
#include "husky_highlevel_controller/Algorithm.hpp"
#include <string>

#include "husky_highlevel_controller/PillarPosition.h"

namespace husky_highlevel_controller {

/*!
 * Class containing the Husky Highlevel Controller
 */
class HuskyHighlevelPerception {
public:
	/*!
	 * Constructor.
	 */
	HuskyHighlevelPerception(ros::NodeHandle& nodeHandle);

	/*!
	 * Destructor.
	 */
	virtual ~HuskyHighlevelPerception();

private:
	ros::NodeHandle nodeHandle_;
	ros::Subscriber subscriber_;
	ros::Publisher cmd_vel_publisher_;
	void scanCallback(const sensor_msgs::LaserScan& msg);
	void loadParameters();
	void publishPillar(double angle, double distance, double angle_offset, std::string originFrame);

	Algorithm algorithm_;
	std::string scan_topic_;
	int queue_size_;
	float kp_;
	tf2_ros::Buffer tfBuffer_;
	tf2_ros::TransformListener tfListener_;
	ros::Publisher vis_pub_;

};

} /* namespace */
