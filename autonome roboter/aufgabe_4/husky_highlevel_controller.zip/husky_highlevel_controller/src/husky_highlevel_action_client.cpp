#include <ros/ros.h>
#include "husky_highlevel_controller/HuskyHighlevelActionClient.hpp"


int main(int argc, char** argv) {
  ros::init(argc, argv, "husky_highlevel_action_client");
  ros::NodeHandle nodeHandle("~");

  ros::Duration(2.0).sleep();
  husky_highlevel_controller::HuskyHighlevelActionClient HuskyHighlevelActionClient(nodeHandle);
  return 0;
}
