#include <ros/ros.h>
#include "husky_highlevel_controller/HuskyHighlevelPerception.hpp"

int main(int argc, char** argv) {
  ros::init(argc, argv, "husky_highlevel_perception");
  ros::NodeHandle nodeHandle("~");

  husky_highlevel_controller::HuskyHighlevelPerception HuskyHighlevelPerception(nodeHandle);

  ros::spin();
  return 0;
}
