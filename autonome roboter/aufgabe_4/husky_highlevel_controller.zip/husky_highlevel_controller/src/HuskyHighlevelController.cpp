#include "husky_highlevel_controller/HuskyHighlevelController.hpp"

namespace husky_highlevel_controller {

HuskyHighlevelController::HuskyHighlevelController(ros::NodeHandle& nodeHandle) :
  nodeHandle_(nodeHandle), tfListener_(tfBuffer_), actionServer_("husky_drive_pillar", boost::bind(&HuskyHighlevelController::executePillarDrive, this, _1), false)
{
  HuskyHighlevelController::loadParameters();
  subscriber_ = nodeHandle_.subscribe(pillar_topic_, queue_size_, &HuskyHighlevelController::pillarCallback, this);

  cmd_vel_publisher_ = nodeHandle_.advertise<geometry_msgs::Twist>("/cmd_vel", 10);

  vis_pub_ = nodeHandle_.advertise<visualization_msgs::Marker>("visualization_marker", 0);

  ROS_INFO("HuskyHighlevelController started");
  actionServer_.start();
}

HuskyHighlevelController::~HuskyHighlevelController(){
  actionServer_.shutdown();
}


void HuskyHighlevelController::pillarCallback(const husky_highlevel_controller::PillarPosition& msg){
  // get angle and distance to pillar
  minimalDistance = msg.distance;
  pillarAngle = msg.angle;
  angle_offset = msg.angle_offset;
  frame_id = msg.header.frame_id;
  //ROS_INFO("pillar: %f m, %f degrees \n", minimalDistance, pillarAngle);
}

void HuskyHighlevelController::executePillarDrive(const husky_highlevel_controller::HuskyPillarGoalConstPtr& goal){

  min_distance_ = goal->min_distance;

  ros::Rate r(10);

  // drive towards pillar
  geometry_msgs::Twist new_cmd_vel;

  while (minimalDistance > min_distance_){
    new_cmd_vel = algorithm_.calculateAngularVelocity(angle_offset, kp_);
    cmd_vel_publisher_.publish(new_cmd_vel);

    //ROS_INFO("vel lat %f, vel yaw %f\n", new_cmd_vel.linear.x, new_cmd_vel.angular.z);

    feedback_.remaining_distance = minimalDistance;
    actionServer_.publishFeedback(feedback_);

    // publish marker
    double x = minimalDistance * cosf(angle_offset);
    double y = minimalDistance * sinf(angle_offset);
    publishMarker(x, y, frame_id, "odom");
    r.sleep();
  }
  new_cmd_vel.linear.x = 0.0;
  new_cmd_vel.angular.z = 0.0;
  cmd_vel_publisher_.publish(new_cmd_vel);
  result_.destination_reached = true;
  actionServer_.setSucceeded(result_);
}

void HuskyHighlevelController::loadParameters(){
  if (!nodeHandle_.getParam("topic_name_pillar", pillar_topic_)) {ROS_ERROR("Could not find kp parameter!");}
  if (!nodeHandle_.getParam("kp", kp_)) {ROS_ERROR("Could not find kp parameter!");}
}

void HuskyHighlevelController::publishMarker(double x, double y, std::string originFrame, std::string targetFrame){
  geometry_msgs::Pose pose;
  geometry_msgs::TransformStamped transform_stamped;
  visualization_msgs::Marker marker;

  pose.position.x = x;
  pose.position.y = y;
  pose.position.z = -1.5;
  pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(0, -M_PI_2, 0);

  marker.header.stamp = ros::Time();
  marker.id = 0;
  marker.type = visualization_msgs::Marker::ARROW;
  marker.action = visualization_msgs::Marker::ADD;
  marker.scale.x = 1;
  marker.scale.y = 0.1;
  marker.scale.z = 0.1;
  marker.color.a = 1.0;

  // // aufgabe 7 a
  // marker.header.frame_id = originFrame;
  // marker.pose = pose;
  // marker.color.r = 0.0;
  // marker.color.g = 1.0;
  // marker.color.b = 0.0;
  // vis_pub_.publish(marker);

  // aufgabe 7 b
  marker.header.frame_id = targetFrame;
  marker.id = 1;
  marker.color.r = 0.0;
  marker.color.g = 0.0;
  marker.color.b = 1.0;

  try{
    transform_stamped = tfBuffer_.lookupTransform(targetFrame, originFrame, ros::Time(0));
    tf2::doTransform(pose, pose, transform_stamped);
    marker.pose = pose;
    vis_pub_.publish(marker);
  }
  catch(tf::TransformException ex){
      ROS_ERROR("%s", ex.what());
      return;
  }

}

} /* namespace */
