#include "husky_highlevel_controller/HuskyHighlevelPerception.hpp"

namespace husky_highlevel_controller {

HuskyHighlevelPerception::HuskyHighlevelPerception(ros::NodeHandle& nodeHandle) :
  nodeHandle_(nodeHandle), tfListener_(tfBuffer_)
{
  HuskyHighlevelPerception::loadParameters();
  subscriber_ = nodeHandle_.subscribe(scan_topic_, queue_size_, &HuskyHighlevelPerception::scanCallback, this);

  vis_pub_ = nodeHandle_.advertise<husky_highlevel_controller::PillarPosition>("pillar_position", 0);

  ROS_INFO("HuskyHighlevelPerceptionstarted");
}

HuskyHighlevelPerception::~HuskyHighlevelPerception() = default;


void HuskyHighlevelPerception::scanCallback(const sensor_msgs::LaserScan& msg){
  // get angle and distance to pillar
  double minimalDistance;
  float pillarAngle;
  std::tie(pillarAngle, minimalDistance) = algorithm_.getMinimalDistance(msg);

  double angle_offset = ((msg.angle_max - msg.angle_min) / 2) - pillarAngle;

  ROS_INFO("pillar: %f m, %f degrees \n", minimalDistance, pillarAngle);

  publishPillar(pillarAngle, minimalDistance, angle_offset, "base_laser");

}

void HuskyHighlevelPerception::loadParameters(){
  if (!nodeHandle_.getParam("topic_name", scan_topic_)) {ROS_ERROR("Could not find topic_name parameter!");}
  if (!nodeHandle_.getParam("queue_size", queue_size_)) {ROS_ERROR("Could not find queue_size parameter!");}
}

void HuskyHighlevelPerception::publishPillar(double angle, double distance, double angle_offset, std::string originFrame){
  husky_highlevel_controller::PillarPosition pillar_position;
  pillar_position.header.frame_id = originFrame;
  pillar_position.header.stamp = ros::Time::now();
  pillar_position.angle = angle;
  pillar_position.distance = distance;
  pillar_position.angle_offset = angle_offset;

  vis_pub_.publish(pillar_position);
}

} /* namespace */
