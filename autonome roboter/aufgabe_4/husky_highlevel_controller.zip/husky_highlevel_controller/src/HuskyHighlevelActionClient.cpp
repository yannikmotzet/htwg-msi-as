#include "husky_highlevel_controller/HuskyHighlevelActionClient.hpp"

namespace husky_highlevel_controller {

HuskyHighlevelActionClient::HuskyHighlevelActionClient(ros::NodeHandle& nodeHandle) :
  nodeHandle_(nodeHandle), actionClient_("husky_drive_pillar", true)
{
  actionClient_.waitForServer();

  // send a goal to the action
  goal.min_distance = 1.0;
  actionClient_.sendGoal(goal);

  //wait for the action to return
  bool finished_before_timeout = actionClient_.waitForResult(ros::Duration(30.0));

  if (finished_before_timeout)
  {
    actionlib::SimpleClientGoalState state = actionClient_.getState();
    ROS_INFO("Action finished: %s",state.toString().c_str());
  }
  else
    ROS_INFO("Action did not finish before the time out.");
}

HuskyHighlevelActionClient::~HuskyHighlevelActionClient() = default;

} /* namespace */
