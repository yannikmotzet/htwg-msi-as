### annotations
* set variable in .bashrc. ``` export HUSKY_LMS1XX_ENABLED=1 ```